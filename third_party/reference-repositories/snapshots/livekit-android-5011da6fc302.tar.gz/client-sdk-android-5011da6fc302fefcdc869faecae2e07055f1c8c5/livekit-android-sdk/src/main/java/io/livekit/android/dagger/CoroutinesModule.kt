/*
 * Copyright 2023-2026 LiveKit, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.dagger

import dagger.Module
import dagger.Provides
import kotlinx.coroutines.Dispatchers
import javax.inject.Named

/**
 * @suppress
 */
@Module
@Suppress("InjectDispatcher")
internal object CoroutinesModule {
    @Provides
    @Named(InjectionNames.DISPATCHER_DEFAULT)
    fun defaultDispatcher() = Dispatchers.Default

    @Provides
    @Named(InjectionNames.DISPATCHER_IO)
    fun ioDispatcher() = Dispatchers.IO

    @Provides
    @Named(InjectionNames.DISPATCHER_MAIN)
    fun mainDispatcher() = Dispatchers.Main

    @Provides
    @Named(InjectionNames.DISPATCHER_UNCONFINED)
    fun unconfinedDispatcher() = Dispatchers.Unconfined
}
