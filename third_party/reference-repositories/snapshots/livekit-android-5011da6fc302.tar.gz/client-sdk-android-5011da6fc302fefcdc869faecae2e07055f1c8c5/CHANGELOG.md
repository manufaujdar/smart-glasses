# client-sdk-android

## 2.27.0

### Minor Changes

- Add `LocalAudioTrack.applyOptions`, which allows updating the audio track options on the fly. - [#974](https://github.com/livekit/client-sdk-android/pull/974) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Fix custom LocalAudioTrackOptions not applying correctly - [#974](https://github.com/livekit/client-sdk-android/pull/974) ([@davidliu](https://github.com/davidliu))

- Properly update the server info after reconnect - [#962](https://github.com/livekit/client-sdk-android/pull/962) ([@davidliu](https://github.com/davidliu))

- Scoped the protobuf consumer keep rule to the SDK's generated messages and the well-known types they embed, instead of every GeneratedMessageLite subclass in the consuming app. - [#975](https://github.com/livekit/client-sdk-android/pull/975) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Fix native memory leaks on video track publish/unpublish cycles (#521). `LocalVideoTrack.dispose()` now disposes its backing `VideoSource`, which was previously left undisposed and leaked for the lifetime of the process (only the track and capturer were released). Unpublishing a video track now also stops its `RtpTransceiver`, along with any extra transceivers added for backup codecs; since a new transceiver is created on every publish, removing the track from its sender alone left them retained until the connection closed. - [#971](https://github.com/livekit/client-sdk-android/pull/971) ([@adrian-niculescu](https://github.com/adrian-niculescu))

## 2.26.1

### Patch Changes

- Fix audio output getting stuck on the earpiece after reconnecting on a reused `Room` (Android 12+). `AudioSwitchHandler.stop()` now clears its `audioSwitch` reference synchronously (and the field is `@Volatile`) so a subsequent `start()` reliably observes the teardown and re-creates the switch, instead of racing the posted teardown runnable and reusing a stale, already-stopped switch. - [#967](https://github.com/livekit/client-sdk-android/pull/967) ([@YashJainSC](https://github.com/YashJainSC))

- Emit `TrackSubscriptionFailed` events through `Room` and `RemoteParticipant` when the server detects a subscription failure - [#959](https://github.com/livekit/client-sdk-android/pull/959) ([@davidliu](https://github.com/davidliu))

- Clarified documentation regarding data stream receivers and errors - [#965](https://github.com/livekit/client-sdk-android/pull/965) ([@davidliu](https://github.com/davidliu))

## 2.26.0

### Minor Changes

- Allow customizing `maxRoundTripLatency` on `LocalParticipant.performRpc` for high-latency networks - [#953](https://github.com/livekit/client-sdk-android/pull/953) ([@1egoman](https://github.com/1egoman))

- Add support for RPC V2 - [#946](https://github.com/livekit/client-sdk-android/pull/946) ([@1egoman](https://github.com/1egoman))

### Patch Changes

- Change proguard rule for protobufs to official recommended rule, allowing unused protobuf classes to be removed with minification - [#946](https://github.com/livekit/client-sdk-android/pull/946) ([@1egoman](https://github.com/1egoman))

- Increased max data packet size for `LocalParticipant.publishData` to 65535 bytes (64KB - 1) - [#948](https://github.com/livekit/client-sdk-android/pull/948) ([@1egoman](https://github.com/1egoman))

## 2.25.3

### Patch Changes

- docs(audio): clarify that `AudioSwitchHandler.selectDevice()` is sticky and overrides `preferredDeviceList`. Document that callers who only need a different priority order should set `preferredDeviceList` instead, and that `selectDevice(null)` clears a sticky selection. - [#941](https://github.com/livekit/client-sdk-android/pull/941) ([@daxiondi](https://github.com/daxiondi))

- Update libwebrtc to 144.7559.05 - [#936](https://github.com/livekit/client-sdk-android/pull/936) ([@davidliu](https://github.com/davidliu))

- fix: resume joinContinuation when LEAVE received during reconnect handshake to avoid reconnection loop hanging issue - [#934](https://github.com/livekit/client-sdk-android/pull/934) ([@YashJainSC](https://github.com/YashJainSC))

- Fixed silent loss of reliable data when DataChannel.send returned false and when buffered items were replayed across multiple resumes. - [#921](https://github.com/livekit/client-sdk-android/pull/921) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Fix byte streams not sending the name of the bytestream - [#939](https://github.com/livekit/client-sdk-android/pull/939) ([@davidliu](https://github.com/davidliu))

- Update AudioSwitch to handle potential exception when unregistering audio device listeners - [#944](https://github.com/livekit/client-sdk-android/pull/944) ([@davidliu](https://github.com/davidliu))

## 2.25.2

### Patch Changes

- Fix Room.connect not properly throwing ConnectException for websocket connection failures during Room.join() - [#926](https://github.com/livekit/client-sdk-android/pull/926) ([@davidliu](https://github.com/davidliu))

- Fix reconnect potentially getting cancelled by websocket failure - [#926](https://github.com/livekit/client-sdk-android/pull/926) ([@davidliu](https://github.com/davidliu))

- Fixed RTCEngine.addTrack leaking pendingTrackResolvers entries on timeout or caller cancellation, which previously caused subsequent publishes of the same track to fail with DuplicateTrackException until the connection was torn down. - [#920](https://github.com/livekit/client-sdk-android/pull/920) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Fix exception when resending data channel messages after a resume - [#923](https://github.com/livekit/client-sdk-android/pull/923) ([@davidliu](https://github.com/davidliu))

## 2.25.1

### Patch Changes

- Add convenience constructor to E2EEOptions for shared key encryption - [#917](https://github.com/livekit/client-sdk-android/pull/917) ([@davidliu](https://github.com/davidliu))

## 2.25.0

### Minor Changes

- AudioOptions: Added disableAudioPrewarming flag - [#912](https://github.com/livekit/client-sdk-android/pull/912) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Fix potential leak for StreamSender caused by exceptions - [#913](https://github.com/livekit/client-sdk-android/pull/913) ([@davidliu](https://github.com/davidliu))

- Update audio handling to use AudioManager communication device APIs on S and above - [#910](https://github.com/livekit/client-sdk-android/pull/910) ([@davidliu](https://github.com/davidliu))

- Rethrow cancellation exceptions for coroutines - [#913](https://github.com/livekit/client-sdk-android/pull/913) ([@davidliu](https://github.com/davidliu))

- Implement changing preferred audio device list on AudioSwitchHandler mid-call - [#910](https://github.com/livekit/client-sdk-android/pull/910) ([@davidliu](https://github.com/davidliu))

## 2.24.1

### Patch Changes

- Fix LocalParticipant.publishData throwing exception for packets over 15KB - [#902](https://github.com/livekit/client-sdk-android/pull/902) ([@xianshijing-lk](https://github.com/xianshijing-lk))

## 2.24.0

### Minor Changes

- Add setting custom reconnect policy - [#894](https://github.com/livekit/client-sdk-android/pull/894) ([@davidliu](https://github.com/davidliu))

- Update libwebrtc to m144 - [#886](https://github.com/livekit/client-sdk-android/pull/886) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Fix resume not working sometimes after connection loss/gain - [#894](https://github.com/livekit/client-sdk-android/pull/894) ([@davidliu](https://github.com/davidliu))

- Fix transcription attributes not converting correctly - [#889](https://github.com/livekit/client-sdk-android/pull/889) ([@davidliu](https://github.com/davidliu))

- Specifically keep native libwebrtc methods from being obfuscated - [#893](https://github.com/livekit/client-sdk-android/pull/893) ([@davidliu](https://github.com/davidliu))

- Properly cancel jobs awaiting on DataChannel low buffer instead of completing on dispose - [#897](https://github.com/livekit/client-sdk-android/pull/897) ([@davidliu](https://github.com/davidliu))

- Fix exception not being caught when using LocalParticipant.publishData - [#897](https://github.com/livekit/client-sdk-android/pull/897) ([@davidliu](https://github.com/davidliu))

## 2.23.5

### Patch Changes

- Fix not detecting server supported video codecs correctly - [#876](https://github.com/livekit/client-sdk-android/pull/876) ([@davidliu](https://github.com/davidliu))

- Remove Timber from dependencies - [#874](https://github.com/livekit/client-sdk-android/pull/874) ([@davidliu](https://github.com/davidliu))

## 2.23.4

### Patch Changes

- Make selfie segmenter work better - [#861](https://github.com/livekit/client-sdk-android/pull/861) ([@Deneath](https://github.com/Deneath))

- Ensure child jobs are cleaned up on ICE reconnect timeout - [#870](https://github.com/livekit/client-sdk-android/pull/870) ([@davidliu](https://github.com/davidliu))

- Cancel websocket when join coroutine is cancelled - [#871](https://github.com/livekit/client-sdk-android/pull/871) ([@davidliu](https://github.com/davidliu))

- Concurrency fixes for SignalClient connection - [#871](https://github.com/livekit/client-sdk-android/pull/871) ([@davidliu](https://github.com/davidliu))

## 2.23.3

### Patch Changes

- Optimised connection params building - [#852](https://github.com/livekit/client-sdk-android/pull/852) ([@pulakdp](https://github.com/pulakdp))

- Fixed ScreenCaptureConnection suspending forever when bindService fails and crashing when resuming canceled continuations. - [#838](https://github.com/livekit/client-sdk-android/pull/838) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Migrate from Klaxon decoding to kotlinx-serialization for AgentAttribute deserialization - [#851](https://github.com/livekit/client-sdk-android/pull/851) ([@davidliu](https://github.com/davidliu))

- perf: Skip Klaxon parsing for empty agent attribute maps - [#849](https://github.com/livekit/client-sdk-android/pull/849) ([@YashJainSC](https://github.com/YashJainSC))

## 2.23.2

### Patch Changes

- Fix exception when parsing AgentAttribute inputs and outputs - [#847](https://github.com/livekit/client-sdk-android/pull/847) ([@davidliu](https://github.com/davidliu))

- Properly reset network callback manager after disconnect - [#841](https://github.com/livekit/client-sdk-android/pull/841) ([@davidliu](https://github.com/davidliu))

- Fixed audio focus not being abandoned on pre-O devices due to mismatched listener instance. - [#837](https://github.com/livekit/client-sdk-android/pull/837) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Fixed file descriptor leak in ByteStreamSender where Source was not closed after reading. - [#839](https://github.com/livekit/client-sdk-android/pull/839) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Fixed data race in `CameraEventsDispatchHandler` by using `CopyOnWriteArraySet` for thread-safe iteration. - [#822](https://github.com/livekit/client-sdk-android/pull/822) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Fixed Room getting stuck in CONNECTING state after failed connect attempts. - [#836](https://github.com/livekit/client-sdk-android/pull/836) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Fix thread visibility issues in SignalClient that could cause messages to be silently dropped. - [#819](https://github.com/livekit/client-sdk-android/pull/819) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Fix race condition when sending sync state before tracks are subscribed - [#831](https://github.com/livekit/client-sdk-android/pull/831) ([@davidliu](https://github.com/davidliu))

- Don't throw on invalid values for Agent enum types - [#847](https://github.com/livekit/client-sdk-android/pull/847) ([@davidliu](https://github.com/davidliu))

- Add overload for TokenSource.fromEndpoint that accepts a string for the url - [#844](https://github.com/livekit/client-sdk-android/pull/844) ([@davidliu](https://github.com/davidliu))

- Fixed screen sharing with VP9/AV1 codecs - [#828](https://github.com/livekit/client-sdk-android/pull/828) ([@pblazej](https://github.com/pblazej))

- Proguard rule optimizations - [#803](https://github.com/livekit/client-sdk-android/pull/803) ([@davidliu](https://github.com/davidliu))

## 2.23.1

### Patch Changes

- Fixed non-local return in `onConnectionQuality` that caused lost connection quality updates for remaining participants when one participant was not found in the list. - [#817](https://github.com/livekit/client-sdk-android/pull/817) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Fixed impossible empty streams check in Room.onAddTrack that could crash if WebRTC called onAddTrack with an empty streams array. - [#816](https://github.com/livekit/client-sdk-android/pull/816) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Improve thread-safety and reconnection reliability for hasPublished flag. - [#814](https://github.com/livekit/client-sdk-android/pull/814) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Fixed `ConcurrentModificationException` in `LocalAudioTrack.dispose()` when sinks are registered. - [#820](https://github.com/livekit/client-sdk-android/pull/820) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Fix LocalParticipant jobs map clean-up when unpublishing tracks. - [#807](https://github.com/livekit/client-sdk-android/pull/807) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Fixed PeerConnectionTransport coroutine scope not being cancelled on close. - [#818](https://github.com/livekit/client-sdk-android/pull/818) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Improve reconnection reliability by hardening state flags and synchronizing data channel receive state. - [#806](https://github.com/livekit/client-sdk-android/pull/806) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Remove reference to internal OkHttp method - [#811](https://github.com/livekit/client-sdk-android/pull/811) ([@davidliu](https://github.com/davidliu))

- Increase RTC negotiation reliability by dropping outdated sdp answers and forwarding offer ids - [#813](https://github.com/livekit/client-sdk-android/pull/813) ([@davidliu](https://github.com/davidliu))

- Fixed ProGuard/R8 minification crash in release builds when using AgentAttributes. Added @Keep annotations to Klaxon-based data classes and updated ProGuard rules to prevent obfuscation of reflection-based JSON parsing classes. #808 - [#809](https://github.com/livekit/client-sdk-android/pull/809) ([@adrian-niculescu](https://github.com/adrian-niculescu))

- Update WebRTC-SDK to 137.7151.05. - [#824](https://github.com/livekit/client-sdk-android/pull/824) ([@davidliu](https://github.com/davidliu))

  - Fixes echo cancellation and noise suppression failing to enable.
  - Fixes microphone not shutting off when muted.

## 2.23.0

### Minor Changes

- Change TokenSource.fetch methods to return Result<TokenSourceResponse> to explicitly handle exceptions - [#802](https://github.com/livekit/client-sdk-android/pull/802) ([@davidliu](https://github.com/davidliu))

- Add support for multiple listeners on AudioSwitchHandler - [#802](https://github.com/livekit/client-sdk-android/pull/802) ([@davidliu](https://github.com/davidliu))

- Rename AgentState to AgentSdkState - [#802](https://github.com/livekit/client-sdk-android/pull/802) ([@davidliu](https://github.com/davidliu))

- Deprecate Room.withPreconnectAudio method. - [#802](https://github.com/livekit/client-sdk-android/pull/802) ([@davidliu](https://github.com/davidliu))

  - Set AudioTrackPublishDefaults.preconnect = true on the RoomOptions instead to use the preconnect buffer.

- Expose agentAttributes as a value on Participant - [#802](https://github.com/livekit/client-sdk-android/pull/802) ([@davidliu](https://github.com/davidliu))

- Expose the server info of the currently connected server on Room - [#802](https://github.com/livekit/client-sdk-android/pull/802) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Fix crash when cleaning up local participant - [#802](https://github.com/livekit/client-sdk-android/pull/802) ([@davidliu](https://github.com/davidliu))

- Fix crash when creating audio track for communication mode workaround - [#805](https://github.com/livekit/client-sdk-android/pull/805) ([@davidliu](https://github.com/davidliu))

## 2.22.1

### Patch Changes

- Fixed camera indicator remaining on after network disconnection by disposing orphaned tracks from failed reconnection attempts (#296) - [#798](https://github.com/livekit/client-sdk-android/pull/798) ([@adrian-niculescu](https://github.com/adrian-niculescu))

## 2.22.0

### Minor Changes

- Extract CameraXProvider and expose it. - [#754](https://github.com/livekit/client-sdk-android/pull/754) ([@KasemJaffer](https://github.com/KasemJaffer))

### Patch Changes

- Fix camera lookup to check physicalId - [#792](https://github.com/livekit/client-sdk-android/pull/792) ([@KasemJaffer](https://github.com/KasemJaffer))

## 2.21.1

### Patch Changes

- #721 Fixed publisher negotiation race condition causing ICE timeouts. - [#789](https://github.com/livekit/client-sdk-android/pull/789) ([@adrian-niculescu](https://github.com/adrian-niculescu))

## 2.21.0

### Minor Changes

- End to end encryption for data channels option - [#762](https://github.com/livekit/client-sdk-android/pull/762) ([@davidliu](https://github.com/davidliu))

  - Added EncryptionType fields to DataReceived events and StreamInfo objects to indicate the
    encryption status.

- Add TokenSource implementation for use with token servers - [#769](https://github.com/livekit/client-sdk-android/pull/769) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Increase RPC method max roundtrip time to 7s - [#775](https://github.com/livekit/client-sdk-android/pull/775) ([@davidliu](https://github.com/davidliu))

## 2.20.3

### Patch Changes

- Switch to using header based auth bearer token - [#770](https://github.com/livekit/client-sdk-android/pull/770) ([@davidliu](https://github.com/davidliu))

## 2.20.2

### Patch Changes

- Remove unneeded suspend modifier from registerRpcMethod - [#757](https://github.com/livekit/client-sdk-android/pull/757) ([@davidliu](https://github.com/davidliu))

- Fix crash when publishing disposed tracks - [#758](https://github.com/livekit/client-sdk-android/pull/758) ([@davidliu](https://github.com/davidliu))

- Fix race condition when releasing Room object - [#756](https://github.com/livekit/client-sdk-android/pull/756) ([@davidliu](https://github.com/davidliu))

- Fix VirtualBackgroundVideoProcessor not responding to changes in backgroundImage - [#752](https://github.com/livekit/client-sdk-android/pull/752) ([@davidliu](https://github.com/davidliu))

- Ensure room is disconnected before releasing resources - [#756](https://github.com/livekit/client-sdk-android/pull/756) ([@davidliu](https://github.com/davidliu))

## 2.20.1

### Patch Changes

- Fix crash caused by extra simulcast layers equal to original resolution - [#749](https://github.com/livekit/client-sdk-android/pull/749) ([@davidliu](https://github.com/davidliu))

- Wrap exceptions thrown in sendText and sendFile into Result - [#749](https://github.com/livekit/client-sdk-android/pull/749) ([@davidliu](https://github.com/davidliu))

## 2.20.0

### Minor Changes

- Update libwebrtc to 137.7151.03 - [#742](https://github.com/livekit/client-sdk-android/pull/742) ([@davidliu](https://github.com/davidliu))

- Return streamInfo from datastream send helper methods - [#741](https://github.com/livekit/client-sdk-android/pull/741) ([@davidliu](https://github.com/davidliu))

- Add simulcastLayers to VideoTrackPublishOptions for directly specifying the resolutions to use - [#746](https://github.com/livekit/client-sdk-android/pull/746) ([@davidliu](https://github.com/davidliu))

- Add H265 as a supported codec - [#742](https://github.com/livekit/client-sdk-android/pull/742) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- E2E reliability for data channels with resending after reconnects - [#738](https://github.com/livekit/client-sdk-android/pull/738) ([@davidliu](https://github.com/davidliu))

- Fix default simulcast layers using a lower than intended resolution - [#746](https://github.com/livekit/client-sdk-android/pull/746) ([@davidliu](https://github.com/davidliu))

- Properly use screenShareTrackPublishDefaults when manually publishing a screenshare track - [#746](https://github.com/livekit/client-sdk-android/pull/746) ([@davidliu](https://github.com/davidliu))

## 2.19.1

### Patch Changes

- Fixed ProGuard rules to keep JniInit class for WebRTC native registration (#735) - [#736](https://github.com/livekit/client-sdk-android/pull/736) ([@adrian-niculescu](https://github.com/adrian-niculescu))

## 2.19.0

### Minor Changes

- Add types for agent and transcription attributes - [#733](https://github.com/livekit/client-sdk-android/pull/733) ([@davidliu](https://github.com/davidliu))

- Update libwebrtc to 137.7151.01 - [#727](https://github.com/livekit/client-sdk-android/pull/727) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Fix IllegalStateException when switchCamera of localVideoTrack - [#725](https://github.com/livekit/client-sdk-android/pull/725) ([@binkos](https://github.com/binkos))

- Make blurRadius in the VirtualBackgroundTransformer variable to allow for dynamically changing the value. - [#731](https://github.com/livekit/client-sdk-android/pull/731) ([@binkos](https://github.com/binkos))

- Add sendText and sendFile helper methods to LocalParticipant for ease of use - [#732](https://github.com/livekit/client-sdk-android/pull/732) ([@davidliu](https://github.com/davidliu))

- Add default name of "unknown" for StreamByteOptions to allow for no-arg construction - [#732](https://github.com/livekit/client-sdk-android/pull/732) ([@davidliu](https://github.com/davidliu))

## 2.18.3

### Patch Changes

- Move audio handling to background thread to avoid UI freezes. - [#715](https://github.com/livekit/client-sdk-android/pull/715) ([@davidliu](https://github.com/davidliu))

## 2.18.2

### Patch Changes

- Properly return Result on ByteStreamSender convenience methods - [#709](https://github.com/livekit/client-sdk-android/pull/709) ([@davidliu](https://github.com/davidliu))

## 2.18.1

### Patch Changes

- Fix not being able to publish immediately after connecting - [#706](https://github.com/livekit/client-sdk-android/pull/706) ([@davidliu](https://github.com/davidliu))

## 2.18.0

### Minor Changes

- Refactor some internal data message sending methods to use Result instead of throwing Exceptions to - [#703](https://github.com/livekit/client-sdk-android/pull/703) ([@davidliu](https://github.com/davidliu))
  fix crashes.

## 2.17.1

### Patch Changes

- Update CameraX dependency to 1.4.2 - [#694](https://github.com/livekit/client-sdk-android/pull/694) ([@davidliu](https://github.com/davidliu))

- Avoid a crash on reconnection when a track is disposed - [#691](https://github.com/livekit/client-sdk-android/pull/691) ([@jeankruger](https://github.com/jeankruger))

## 2.17.0

### Minor Changes

- Change isMicrophoneEnabled, isCameraEnabled, isScreenshareEnabled to FlowObservable variables - [#685](https://github.com/livekit/client-sdk-android/pull/685) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Fix switchCamera not working if the camera id is physical id - [#676](https://github.com/livekit/client-sdk-android/pull/676) ([@KasemJaffer](https://github.com/KasemJaffer))

- Fix sending pre-connect audio data when byte buffer has backing array - [#678](https://github.com/livekit/client-sdk-android/pull/678) ([@davidliu](https://github.com/davidliu))

- Specify default values for StreamTextOptions and streamText - [#688](https://github.com/livekit/client-sdk-android/pull/688) ([@davidliu](https://github.com/davidliu))

## 2.16.0

### Minor Changes

- Unorder the lossy data channel - [#665](https://github.com/livekit/client-sdk-android/pull/665) ([@bcherry](https://github.com/bcherry))

- Add pre-connect audio for use with agents - [#666](https://github.com/livekit/client-sdk-android/pull/666) ([@davidliu](https://github.com/davidliu))

  See Room.withPreconnectAudio for details.

- CameraX: support for selecting cameras by their physical id - [#668](https://github.com/livekit/client-sdk-android/pull/668) ([@KasemJaffer](https://github.com/KasemJaffer))

- Add Participant.State and related events - [#666](https://github.com/livekit/client-sdk-android/pull/666) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Fix NPE when streaming text - [#670](https://github.com/livekit/client-sdk-android/pull/670) ([@davidliu](https://github.com/davidliu))

- Add rpc handler methods to Room class for convenience. - [#663](https://github.com/livekit/client-sdk-android/pull/663) ([@davidliu](https://github.com/davidliu))

- Fix outgoing datastreams incorrectly padding data - [#666](https://github.com/livekit/client-sdk-android/pull/666) ([@davidliu](https://github.com/davidliu))

## 2.15.0

### Minor Changes

- Add VirtualBackgroundVideoProcessor and track-processors package - [#660](https://github.com/livekit/client-sdk-android/pull/660) ([@davidliu](https://github.com/davidliu))

## 2.14.3

### Patch Changes

- Fixes disconnect issue - [#656](https://github.com/livekit/client-sdk-android/pull/656) ([@jeankruger](https://github.com/jeankruger))

## 2.14.2

### Patch Changes

- Fix CameraXSession not setting the target capture format correctly - [#652](https://github.com/livekit/client-sdk-android/pull/652) ([@davidliu](https://github.com/davidliu))

- Improved handling of track publication failures by introducing a new TrackPublicationFailed event and fixing a broken state issue where the track remained active but inaccessible, causing the microphone or camera to stay on without a published track and leading to unreliable republishing. - [#637](https://github.com/livekit/client-sdk-android/pull/637) ([@jeankruger](https://github.com/jeankruger))

## 2.14.1

### Patch Changes

- Fix ConcurrentModificationException in IncomingDataStreamManager - [#642](https://github.com/livekit/client-sdk-android/pull/642) ([@davidliu](https://github.com/davidliu))

- Dedupe supported codecs to provide valid SDP - [#643](https://github.com/livekit/client-sdk-android/pull/643) ([@davidliu](https://github.com/davidliu))

## 2.14.0

### Minor Changes

- Implement data streams feature - [#625](https://github.com/livekit/client-sdk-android/pull/625) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Unpublish the screen sharing track on stop and introduce ScreenCaptureParams to be able to define the notification and set a callback for onStop - [#626](https://github.com/livekit/client-sdk-android/pull/626) ([@jeankruger](https://github.com/jeankruger))

## 2.13.0

### Minor Changes

- Prewarm audio to speed up mic publishing - [#623](https://github.com/livekit/client-sdk-android/pull/623) ([@davidliu](https://github.com/davidliu))

- Fast track publication support - [#612](https://github.com/livekit/client-sdk-android/pull/612) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Fix publish deadlock when no response from server - [#618](https://github.com/livekit/client-sdk-android/pull/618) ([@davidliu](https://github.com/davidliu))

- Add SCREEN_SHARE_AUDIO as a Track.Source.Type - [#610](https://github.com/livekit/client-sdk-android/pull/610) ([@davidliu](https://github.com/davidliu))

- Surface canPublishSources, canUpdateMetadata, and canSubscribeMetrics on ParticipantPermission - [#610](https://github.com/livekit/client-sdk-android/pull/610) ([@davidliu](https://github.com/davidliu))

- Fast fail attempts to publish without permissions - [#618](https://github.com/livekit/client-sdk-android/pull/618) ([@davidliu](https://github.com/davidliu))

## 2.12.3

### Patch Changes

- Fixes deadlock on publish track - [#604](https://github.com/livekit/client-sdk-android/pull/604) ([@jeankruger](https://github.com/jeankruger))

## 2.12.2

### Patch Changes

- Add version number to rpc requests - [#605](https://github.com/livekit/client-sdk-android/pull/605) ([@davidliu](https://github.com/davidliu))

## 2.12.1

### Patch Changes

- Fix documented default of preferredDeviceList in AudioSwitchHandler - [#584](https://github.com/livekit/client-sdk-android/pull/584) ([@davidliu](https://github.com/davidliu))

- Allow access to participant field in ParticipantAttributesChanged event - [#591](https://github.com/livekit/client-sdk-android/pull/591) ([@binkos](https://github.com/binkos))

## 2.12.0

### Minor Changes

- Default prioritizing speaker over earpiece - [#579](https://github.com/livekit/client-sdk-android/pull/579) ([@davidliu](https://github.com/davidliu))

- Implement RPC - [#578](https://github.com/livekit/client-sdk-android/pull/578) ([@davidliu](https://github.com/davidliu))

- Explicitly expose AudioSwitchHandler from Room for easier audio handling - [#579](https://github.com/livekit/client-sdk-android/pull/579) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Add publishDTMF method for Sending DTMF signals to SIP Participant - [#576](https://github.com/livekit/client-sdk-android/pull/576) ([@dipak140](https://github.com/dipak140))

## 2.11.1

### Patch Changes

- Fix maxFps not applying for very low framerates - [#573](https://github.com/livekit/client-sdk-android/pull/573) ([@davidliu](https://github.com/davidliu))

## 2.11.0

### Minor Changes

- Add use cases to CameraX createCameraProvider - [#536](https://github.com/livekit/client-sdk-android/pull/536) ([@KasemJaffer](https://github.com/KasemJaffer))

- Detect rotation for screenshare tracks - [#552](https://github.com/livekit/client-sdk-android/pull/552) ([@davidliu](https://github.com/davidliu))

- Default to scaling and cropping camera output to fit desired dimensions - [#558](https://github.com/livekit/client-sdk-android/pull/558) ([@davidliu](https://github.com/davidliu))

  - This behavior may be turned off through the `VideoCaptureParams.adaptOutputToDimensions`

- Add separate default capture/publish options for screenshare tracks - [#552](https://github.com/livekit/client-sdk-android/pull/552) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Add AudioPresets and increase default audio max bitrate to 48kbps - [#551](https://github.com/livekit/client-sdk-android/pull/551) ([@davidliu](https://github.com/davidliu))

- Fix crash when setting publishing layers - [#559](https://github.com/livekit/client-sdk-android/pull/559) ([@davidliu](https://github.com/davidliu))

- Added VideoFrameCapturer for pushing video frames directly - [#538](https://github.com/livekit/client-sdk-android/pull/538) ([@davidliu](https://github.com/davidliu))

- Fix surface causing null pointer exception on some devices - [#544](https://github.com/livekit/client-sdk-android/pull/544) ([@KasemJaffer](https://github.com/KasemJaffer))

- Update Kotlin dependency to 1.9.25 - [#552](https://github.com/livekit/client-sdk-android/pull/552) ([@davidliu](https://github.com/davidliu))

## 2.10.0

### Minor Changes

- Implement custom audio mixing into audio track - [#528](https://github.com/livekit/client-sdk-android/pull/528) ([@davidliu](https://github.com/davidliu))

- Update to webrtc-sdk 125.6422.06.1 - [#528](https://github.com/livekit/client-sdk-android/pull/528) ([@davidliu](https://github.com/davidliu))

- Implement screen share audio capturer - [#528](https://github.com/livekit/client-sdk-android/pull/528) ([@davidliu](https://github.com/davidliu))

## 2.9.0

### Minor Changes

- Implement LocalAudioTrack.addSink to receive audio data from local mic - [#516](https://github.com/livekit/client-sdk-android/pull/516) ([@davidliu](https://github.com/davidliu))

- Implement client metrics - [#511](https://github.com/livekit/client-sdk-android/pull/511) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- Properly dispose peer connection on RTC thread - [#506](https://github.com/livekit/client-sdk-android/pull/506) ([@davidliu](https://github.com/davidliu))

- Documentation updates for LocalParticipant methods - [#510](https://github.com/livekit/client-sdk-android/pull/510) ([@davidliu](https://github.com/davidliu))

- Initialize WebRTC library only once - [#508](https://github.com/livekit/client-sdk-android/pull/508) ([@davidliu](https://github.com/davidliu))

## 2.8.1

### Patch Changes

- Fix local video tracks not rendering processed frames - [#495](https://github.com/livekit/client-sdk-android/pull/495) ([@davidliu](https://github.com/davidliu))

- Add utility class NoDropVideoProcessor to force video processing while not connected - [#495](https://github.com/livekit/client-sdk-android/pull/495) ([@davidliu](https://github.com/davidliu))

- More fixes for crashes caused by using disposed track - [#497](https://github.com/livekit/client-sdk-android/pull/497) ([@davidliu](https://github.com/davidliu))

## 2.8.0

### Minor Changes

- Implement LocalTrackSubscribed event - [#489](https://github.com/livekit/client-sdk-android/pull/489) ([@davidliu](https://github.com/davidliu))

- Add first and last received times to TranscriptionSegment - [#485](https://github.com/livekit/client-sdk-android/pull/485) ([@davidliu](https://github.com/davidliu))

### Patch Changes

- More guarding of rtc api usages to prevent crashes - [#488](https://github.com/livekit/client-sdk-android/pull/488) ([@davidliu](https://github.com/davidliu))

## 2.7.1

### Patch Changes

- Noisily log when a VideoRenderer is used without initializing it first - [#482](https://github.com/livekit/client-sdk-android/pull/482) ([@davidliu](https://github.com/davidliu))

- Fix NPE in RegionProvider when host can't be determined - [#482](https://github.com/livekit/client-sdk-android/pull/482) ([@davidliu](https://github.com/davidliu))
