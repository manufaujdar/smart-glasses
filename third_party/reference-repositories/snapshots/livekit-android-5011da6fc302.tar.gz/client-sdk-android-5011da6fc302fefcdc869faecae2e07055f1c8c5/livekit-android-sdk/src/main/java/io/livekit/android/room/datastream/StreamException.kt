/*
 * Copyright 2025-2026 LiveKit, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room.datastream

sealed class StreamException(message: String? = null) : Exception(message) {
    /**
     * Unable to open a stream with the same ID as an existing open stream.
     */
    class AlreadyOpenedException : StreamException()

    /**
     * Stream closed abnormally by remote participant.
     */
    class AbnormalEndException(message: String? = null) : StreamException(message)

    /**
     * Incoming chunk data could not be decoded.
     */
    class DecodeFailedException : StreamException()

    /**
     * Length exceeded total length specified in stream header.
     */
    class LengthExceededException : StreamException()

    /**
     * Length is less than total length specified in stream header.
     */
    class IncompleteException : StreamException()

    /**
     * Stream terminated before completion.
     */
    class TerminatedException(message: String? = null) : StreamException(message)

    /**
     * Cannot perform operations on an unknown stream.
     */
    class UnknownStreamException : StreamException()

    /**
     * Given destination URL is not a directory.
     */
    class NotDirectoryException : StreamException()

    /**
     * Unable to read information about the file to send.
     */
    class FileInfoUnavailableException : StreamException()

    /**
     * Encryption of the data chunks did not match the declared encryption type.
     */
    class EncryptionTypeMismatch(message: String? = null) : StreamException(message)
}
