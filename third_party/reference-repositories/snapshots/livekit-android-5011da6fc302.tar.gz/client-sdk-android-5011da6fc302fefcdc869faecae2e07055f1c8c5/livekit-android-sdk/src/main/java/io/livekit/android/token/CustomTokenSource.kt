/*
 * Copyright 2025-2026 LiveKit, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.token

import io.livekit.android.util.rethrowIfCancellationSignal

internal class CustomTokenSource(val block: suspend (options: TokenRequestOptions) -> Result<TokenSourceResponse>) : ConfigurableTokenSource {
    override suspend fun fetch(options: TokenRequestOptions): Result<TokenSourceResponse> {
        return try {
            block(options)
        } catch (e: Throwable) {
            e.rethrowIfCancellationSignal()
            Result.failure(e)
        }
    }
}
